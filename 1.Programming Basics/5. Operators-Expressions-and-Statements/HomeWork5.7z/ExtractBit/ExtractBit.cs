﻿using System;
class ExtractBit
{
    static void Main()
    {
        Console.WriteLine("Enter your number");
        int number = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter P - which bit you wanna see: ");
        int p = int.Parse(Console.ReadLine());

        string binaryConvert = Convert.ToString(number, 2);
        Console.WriteLine("Your binary number is: {0}", binaryConvert);

        int number1 = Convert.ToInt32(binaryConvert);
        int mask = 1 << p;

        int secondMask = number & mask;

        if (secondMask != 0)
        {
            Console.WriteLine("The Bit in position {0} is: 1", p);
        }
        else
        {
            Console.WriteLine("The Bit in position {0} is: 0", p);
        }
    }
}


﻿using System;
class Bitwise3thbit
{
    static void Main()
    {
        Console.WriteLine("Enter your number: ");
        int integer = int.Parse(Console.ReadLine());
        int thirdBit = 3;
        
        string integerToBinary = Convert.ToString(integer, 2);
        Console.WriteLine("Your number to binary is {0}", integerToBinary);
        int alreadyConverted = Convert.ToInt32(integerToBinary);
        int mask = integer >> thirdBit;
        int bit = alreadyConverted & mask;

        if (bit != 0)
        {
            Console.WriteLine("The third bit is: 1", thirdBit);
        }
        else
        {
            Console.WriteLine("The third bit is: 0", thirdBit);
        }
    }
}


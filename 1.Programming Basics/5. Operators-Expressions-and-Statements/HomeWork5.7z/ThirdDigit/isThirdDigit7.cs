﻿using System;
class isThirdDigit7
{
    static void Main()
    {
        Console.WriteLine("Enter your number: ");
        int number = int.Parse(Console.ReadLine());
        int numberDividedByHundred = number / 100;
        int thirdDigit = (numberDividedByHundred % 10);
        bool isThirdDigit7 = thirdDigit == 7;
        Console.WriteLine("Is the third digit 7 - " + isThirdDigit7);
    }
}


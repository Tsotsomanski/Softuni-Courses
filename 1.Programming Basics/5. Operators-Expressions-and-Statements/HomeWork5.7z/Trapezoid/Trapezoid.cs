﻿using System;
class Trapezoid
{
    static void Main()
    {
        double a, b, h;
        
        Console.WriteLine("Enter \"a\": ");
        bool isAvalid = !double.TryParse(Console.ReadLine(), out a);

        Console.WriteLine("Enter \"b\": ");
        bool isBvalid = !double.TryParse(Console.ReadLine(), out b);

        Console.WriteLine("Enter \"h\": ");
        bool isHvalid = !double.TryParse(Console.ReadLine(), out h);

        double prefix = 0.5;

        if (isAvalid && isBvalid && isHvalid)
        {
            Console.WriteLine("area = " + Math.Abs(prefix * (a + b) * h));    
        }
        else
        {
            Console.WriteLine("Invalid entry");
        }
    }
}


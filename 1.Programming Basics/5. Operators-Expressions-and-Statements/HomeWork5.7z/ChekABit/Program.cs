﻿using System;
class Program
{
    static void Main()
    {
        string str = "First method";
        Console.WriteLine(str.PadLeft(16));
    }
}


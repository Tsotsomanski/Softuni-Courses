﻿using System;
class OddOrEvenInt
{
    static void Main()
    {
        Console.WriteLine("Enter some number: ");
        int a = int.Parse(Console.ReadLine());
        bool b = (a % 2 == 1 || a % 2 == -1);
        Console.WriteLine("This number is odd: " + b);
    }
}


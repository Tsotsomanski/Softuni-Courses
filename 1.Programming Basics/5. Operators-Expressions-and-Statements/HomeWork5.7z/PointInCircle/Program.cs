﻿using System;
class PointInCircle
{
    static void Main()
    {
        bool chek = false;
        double x, y;
        Console.WriteLine("Enter x: ");
        bool xCheck = double.TryParse(Console.ReadLine(), out x);
        Console.WriteLine("Enter y: ");
        bool yCheck = double.TryParse(Console.ReadLine(), out y);
        if (xCheck && yCheck)
        {
            if ((x >= -1 && y >= -1) && (x <= 5 && y <= 1))
            {

            }
            else
            {
                double displacedX = x - 1;
                double displacedY = y - 1;
                if ((displacedX * displacedX + displacedY * displacedY) <= 9)
                {
                    chek = true;
                }
            }
            Console.WriteLine("Is the point ({0},{1}) within the circle and out of the rectangle?:{2}", x, y, chek);
        }
        else
        {
            Console.WriteLine("Not a valid entry.");
        }

    }
}


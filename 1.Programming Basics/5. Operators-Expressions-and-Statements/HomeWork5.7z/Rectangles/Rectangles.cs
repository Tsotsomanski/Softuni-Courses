﻿using System;
class Rectangles
{
    static void Main()
    {
        string widthFromConsole;
        string hightFromConsole;
        double width;
        double hight;

        do
        {
            Console.WriteLine("Width: ");
            widthFromConsole = Console.ReadLine();
        }
        while (!Double.TryParse(widthFromConsole, out width) || width < 0);

        do
        {
            Console.WriteLine("Hight: ");
            hightFromConsole = Console.ReadLine();
        }
        while (!Double.TryParse(hightFromConsole, out hight) || hight < 0);

        double area = width * hight;
        Console.WriteLine("The rectangle area is: {0} square units", area);
    }
}


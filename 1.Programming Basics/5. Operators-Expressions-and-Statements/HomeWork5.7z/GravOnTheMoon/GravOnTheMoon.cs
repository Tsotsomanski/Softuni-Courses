﻿using System;
class GravOnTheMoon
{
    static void Main()
    {
        double weightOnTheEarth = double.Parse(Console.ReadLine());
        double weightOnTheMoon = weightOnTheEarth * 0.17;
        Console.WriteLine(weightOnTheMoon);
    }
}


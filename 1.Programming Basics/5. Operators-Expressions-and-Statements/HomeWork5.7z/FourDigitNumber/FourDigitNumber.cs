﻿using System;
class FourDigitNumber
{
    static void Main()
    {
        string digFromConsole;
        int number;

        do
	{
        Console.WriteLine("Enter your 4 digit number: ");
        digFromConsole = Console.ReadLine();
	} 
        while (!Int32.TryParse(digFromConsole, out number) || number < 1000 || number > 9999);

        int firstDigit = number % 10;
        
        int restNumberTwo = number / 10;
        int secondDigit = restNumberTwo % 10;

        int restNumberThree = number / 100;
        int thirdDigit = restNumberThree % 10;

        int restNumberFour = number / 1000;
        int fourthDigit = restNumberFour % 10;

        Console.WriteLine("Number " + number);
        Console.WriteLine("Sum of digits " + (firstDigit + secondDigit + thirdDigit + fourthDigit));
        Console.WriteLine("Reversed {0}{1}{2}{3}", firstDigit, secondDigit, thirdDigit, fourthDigit);
        Console.WriteLine("Last digit in front {0}{1}{2}{3}", firstDigit, fourthDigit, thirdDigit, secondDigit);
        Console.WriteLine("Second and third digits exchanged {0}{1}{2}{3}", fourthDigit, secondDigit, thirdDigit, firstDigit);
    }
}


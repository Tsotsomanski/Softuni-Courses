﻿using System;
class Division
{
    static void Main()
    {
        bool chek = false;
        int number;
        Console.WriteLine("Enter your number: ");
        bool isInt = int.TryParse(Console.ReadLine(), out number);

        if (isInt)
        {
            if (number % 7 == 0 && number % 5 == 0)
            {
                chek = true;
            }
            Console.WriteLine("The result of the chek is: {0}", chek);
        }
        else
        {
            Console.WriteLine("Not a valid entry");
        }
    }
}


﻿using System;
class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        object copyRight = 'o';
        Console.WriteLine("{0,5}\n{0,4}{0,2}\n{0,3}{0,4}\n{0,2}{0,2}{0,2}{0,2}", copyRight);
    }
}


﻿using System;
class Program
{
    static void Main()
    {
        int? a = null;
        double? b = null;
        Console.WriteLine(a);
        Console.WriteLine(b);
        int? c = 56;
        Console.WriteLine(c);
        double? d = 35.128132;
        Console.WriteLine(d);
        a = 24;
        Console.WriteLine(a);
    }
}


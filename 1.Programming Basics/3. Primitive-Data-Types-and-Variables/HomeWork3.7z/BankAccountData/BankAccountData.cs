﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("First name: ");
        Console.ReadLine();
        Console.WriteLine("Second name: ");
        Console.ReadLine();
        Console.WriteLine("Last name: ");
        Console.ReadLine();
        Console.WriteLine(" ");
        Console.WriteLine("Available amount of money: ");
        long balance = long.Parse(Console.ReadLine());
        Console.WriteLine("{0:C2}", balance);
        Console.WriteLine(" ");
        Console.WriteLine("Bank name: ");
        Console.ReadLine();
        Console.WriteLine(" ");
        Console.WriteLine("IBAN: ");
        Console.ReadLine();
        Console.WriteLine(" ");
        Console.WriteLine("Card numbers associated with this account: ");
        Console.ReadLine();
        Console.ReadLine();
        Console.ReadLine();
        Console.WriteLine(" ");
        Console.WriteLine("The account is filled. ");
    }
}


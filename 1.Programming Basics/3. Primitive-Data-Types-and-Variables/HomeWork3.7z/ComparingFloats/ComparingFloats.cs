﻿using System;
class Program
{
    static void Main()
    {
        double firstA = 5.3f;
        double firstB = 6.01f;
        double secondA = 5.00000001;
        double secondB = 5.00000003;
        double thirdA = 5.00000005;
        double thirdB = 5.00000001;
        decimal fourthA = -0.0000007m;
        decimal fourthB = 0.00000007m;
        double fifthA = -4.999999;
        double fifthB = -4.999998;
        double sixthA = 4.999999;
        double sixthB = 4.999998;
       }
}


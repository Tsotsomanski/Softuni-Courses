﻿using System;
class Program
{
    static void Main()
    {
        byte a = 97;
        sbyte b = -115;
        ushort c = 52130;
        int d = -1000;
        long e = 4825932;
        Console.WriteLine("a = " + a);
        Console.WriteLine("b = " + b);
        Console.WriteLine("c = " + c);
        Console.WriteLine("d = " + d);
        Console.WriteLine("e = " + e);
    }
}

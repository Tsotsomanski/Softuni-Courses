﻿using System;
class Program
{
    static void Main()
    {
        string quteOne = "The \"use\" of quotations causes difficulties.";
        string quteTwo = @"The ""use"" of quotations causes difficulties.";
        Console.WriteLine(quteOne);
        Console.WriteLine(quteTwo);
    }
}


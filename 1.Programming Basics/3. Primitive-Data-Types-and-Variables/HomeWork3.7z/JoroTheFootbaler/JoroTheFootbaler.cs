﻿using System;
class Program
{
    static void Main()
    {
        string maxWeekend = "52";
        Console.WriteLine("Enter \"t\" for leap year or \"f\" if the year is not leap");
        string leap = Console.ReadLine();
        Console.WriteLine("Enter the number of the holidays: 3; 2; 10; 0;");
        int holidays = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter the number of hometown visit: 2; 3; 5; 1;");
        int hometown = int.Parse(Console.ReadLine()); 
        Console.WriteLine(holidays / 2 + hometown + (52 - hometown) * 2 / 3 + (leap == "t" ? 3 : 0)); 
    }
}


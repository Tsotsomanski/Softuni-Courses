﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Write first name: ");
        string firstName = Console.ReadLine();
        Console.WriteLine("Write last name: ");
        string lastName = Console.ReadLine();
        Console.WriteLine("Enter age: ");
        int age = int.Parse(Console.ReadLine());
        Console.WriteLine("Gender: m / f ");
        Console.ReadLine();
        Console.WriteLine("Personal ID number: ");
        Console.ReadLine();
        Console.WriteLine("Unique employee number: ");
        Console.ReadLine();
        Console.WriteLine(" ");
        Console.WriteLine("The record is complete !");
    }
}


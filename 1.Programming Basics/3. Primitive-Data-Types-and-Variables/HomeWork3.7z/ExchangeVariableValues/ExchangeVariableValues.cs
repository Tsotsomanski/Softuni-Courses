﻿using System;
class Program
{
    static void Main()
    {
        int a = 5;
        int b = 10;
        Console.WriteLine("Before exchange a = " + a + ", b = " + b);
        a = 10;
        b = 5;
        Console.WriteLine("After exchange a = " + a + ", b = " + b);
    }
}


﻿using System;
class Program
{
    static void Main()
    {
        bool isFemale = false;
        Console.WriteLine("Am I female - {0} ", isFemale);
    }
}


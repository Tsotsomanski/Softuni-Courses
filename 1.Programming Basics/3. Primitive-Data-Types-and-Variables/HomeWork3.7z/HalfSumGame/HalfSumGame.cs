﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Enter first number: ");
        int n = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter second number: ");
        int n2 = int.Parse(Console.ReadLine());
        if (n == n2)
        {
            Console.WriteLine("Yes, Sum = " + n);
        }
        else
            Console.WriteLine("No, Diff = " + Math.Abs(n - n2));
            Console.WriteLine();
    }
}

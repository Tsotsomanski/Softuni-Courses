﻿using System;
class Program
{
    static void Main()
    {
        string word1 = "Hello ";
        string word2 = "World !";
        object complete = word1 + word2;
        Console.WriteLine(complete);
        string cast = (string) complete;
        Console.WriteLine(cast);
    }
}


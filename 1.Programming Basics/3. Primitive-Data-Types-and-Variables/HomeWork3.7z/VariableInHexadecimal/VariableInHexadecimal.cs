﻿using System;
class Program
{
    static void Main()
    {
        int intoHexadecimal = 0xFE;
        Console.WriteLine(intoHexadecimal);
    }
}


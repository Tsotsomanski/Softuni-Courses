﻿using System;
class MatrixOfNumbers
{
    static void Main()
    {
        Console.WriteLine("Write a program that reads from the console a positive integer number n (1 ≤ n ≤ 20) and prints a matrix like in the examples below. Use two nested loops.");
        Console.WriteLine();

        Console.WriteLine("Enter an integer: ");
        int n = int.Parse(Console.ReadLine());
        int countCol = 1;
        Console.WriteLine();

        if (n < 1 || n > 20)
        {
            Console.WriteLine("Invalid Input !");
            return;
        }
        for (int i = 1; i <= n; i++)
        {
            for (int ii = i; ii <= n * 2; ii++)
            {
                if (countCol <= n)
                {
                    Console.Write("{0} ", ii);
                    countCol++;
                }
            }
            Console.WriteLine();
            countCol = 1;
        }
    }
}


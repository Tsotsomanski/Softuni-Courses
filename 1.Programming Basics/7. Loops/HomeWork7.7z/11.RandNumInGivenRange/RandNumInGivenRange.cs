﻿using System;
class RandNumInGivenRange
{
    static void Main()
    {
        Console.WriteLine("Write a program that enters 3 integers n, min and max (min ≤ max) and prints n random numbers in the range [min...max]");
        Console.WriteLine();

        Console.WriteLine("Enter the lenght of the array: ");
        int count = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter the min number: ");
        int minInt = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter the max number: ");
        int maxInt = int.Parse(Console.ReadLine());
        int[] array = new int[count];
        if (minInt <= maxInt)
        {
            Random random = new Random();
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write("{0}", random.Next(minInt, maxInt + 1) + " ");
            }
        }
        else
        {
            Console.WriteLine("incorrect input");
        }
    }
}
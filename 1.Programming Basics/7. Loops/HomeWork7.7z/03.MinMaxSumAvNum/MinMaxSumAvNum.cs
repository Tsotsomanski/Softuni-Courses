﻿using System;
class MinMaxSumAvNum
{
    static void Main()
    {
        Console.WriteLine("Write a program that reads from the console a sequence of n integer numbers and returns the minimal, the maximal number, the sum and the average of all numbers (displayed with 2 digits after the decimal point). The input starts by the number n (alone in a line) followed by n lines, each holding an integer number. The output is like in the examples below. ");
        Console.WriteLine();
        Console.Write("Enter a N number = ");

        int n = int.Parse(Console.ReadLine());
        int[] numbers = new int[n];

        for (int i = 0; i < numbers.Length; i++)
        {
            Console.Write("Enter a number = ");
            numbers[i] = int.Parse(Console.ReadLine());
        }

        //FOR TESTING
        //int[] numbers = new int[] { 1, 2, 3, 4, 5 };

        //Init variables Min, Max, Sum and Average
        int min = numbers[0], max = numbers[0], sum = numbers[0];
        float average;

        Console.WriteLine("Variant 1");
        //int[] numbers = new int[] { 1, 2, 3, 4, 5 };
        for (int i = 1; i < numbers.Length; i++)
        {
            if (min > numbers[i])
            {
                min = numbers[i];
            }
            if (max < numbers[i])
            {
                max = numbers[i];
            }
            sum += numbers[i];
        }
        average = sum / numbers.Length;

        Console.WriteLine("min = " + min);
        Console.WriteLine("max = " + max);
        Console.WriteLine("sum = " + sum);
        Console.WriteLine(string.Format("average = {0:0.00}", average));

        Console.WriteLine();
        Console.WriteLine("Variant 2");

        //Init variables Min, Max, Sum and Average
        min = numbers[0];
        max = numbers[0];
        sum = 0;
        average = 0;

        foreach (var number in numbers)
        {
            if (min > number)
            {
                min = number;
            }
            if (max < number)
            {
                max = number;
            }
            sum += number;
        }
        average = sum / numbers.Length;

        Console.WriteLine("min = " + min);
        Console.WriteLine("max = " + max);
        Console.WriteLine("sum = " + sum);
        Console.WriteLine(string.Format("average = {0:0.00}", average));
    }
}


﻿using System;
class RandomizeNumbers
{
    static void Main()
    {
        Console.WriteLine("Write a program that enters in integer n and prints the numbers 1, 2, …, n in random order.");
        Console.WriteLine();

        Console.WriteLine("Please enter \"n\": ");
        int n = int.Parse(Console.ReadLine());
        int[] array = new int[n];
        for (int i = 0; i < n; i++)
        {
            array[i] = i + 1;
        }
        Random random = new Random();
        foreach (int i in array)
        {
            int randNum = random.Next(0, n);
            int temp = array[randNum];
            array[randNum] = array[0];
            array[0] = temp;
        }
        Console.WriteLine(String.Join(" ", array));
    }
}
﻿using System;
class HexaToDec
{
    static void Main()
    {
        Console.WriteLine("Using loops write a program that converts a hexadecimal integer number to its decimal form. The input is entered as string. The output should be a variable of type long. Do not use the built-in .NET functionality.");
        Console.WriteLine();
        Console.WriteLine("Enter a hexadecimal number: ");
        string hexadecimalNum = Console.ReadLine();
        for (int i = 0; i >= 0; i--)
        {
            long decimalNum = Convert.ToInt64(hexadecimalNum, 16);
            Console.WriteLine("The decimal represeentation is: {0}", decimalNum);
        }
    }
}

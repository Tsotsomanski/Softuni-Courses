﻿using System;
class NumberFrom1toN
{
    static void Main()
    {
        Console.WriteLine("Write a program that enters from the console a positive integer n and prints all the numbers from 1 to n, on a single line, separated by a space.");
        Console.WriteLine();
        Console.Write("Enter a N number = ");
        int n = int.Parse(Console.ReadLine());
        
        for (int i = 1; i < n; i++)
        {
            Console.Write(i + " ");
        }
        Console.Write(n);
    }
}


﻿using System;
class DecToBin
{
    static void Main()
    {
        Console.WriteLine("Using loops write a program that converts an integer number to its binary representation. The input is entered as long. The output should be a variable of type string. Do not use the built-in .NET functionality.");
        Console.WriteLine();
        Console.WriteLine("Variant 1");
        Console.WriteLine("Enter a decimal number: ");
        long decNumber = long.Parse(Console.ReadLine());

        for (int i = 0; i >= 0; i--)
        {
            string binNumber = Convert.ToString(decNumber, 2);
            Console.WriteLine(binNumber);
        }
        Console.WriteLine();
        Console.WriteLine("Variant 2");
        Console.WriteLine("Enter a decimal number: ");
        long decimalNum = long.Parse(Console.ReadLine());

        if (decimalNum >= 0)
        {
            string binNumber = Convert.ToString(decimalNum, 2);
            Console.WriteLine(binNumber);
        }
    }
}


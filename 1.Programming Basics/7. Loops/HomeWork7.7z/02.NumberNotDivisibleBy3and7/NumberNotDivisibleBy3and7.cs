﻿using System;
class NumberNotDivisibleBy3and7
{
    static void Main()
    {
        Console.WriteLine("Write a program that enters from the console a positive integer n and prints all the numbers from 1 to n not divisible by 3 and 7, on a single line, separated by a space.");
        Console.WriteLine();
        Console.Write("Enter a N number = ");
        int n = int.Parse(Console.ReadLine());

        Console.WriteLine("Variant 1");
        for (int i = 1; i < n; i++)
        {
            if (i % 3 == 0 || i % 7 == 0)
            {
                continue;
            }

            Console.Write(i + " ");
        }

        Console.Write(n);

        Console.WriteLine();
        Console.WriteLine("Variant 2");

        for (int i = 1; i < n; i++)
        {
            if (!(i % 3 == 0 || i % 7 == 0))
            {
                Console.Write(i + " ");
            }
        }
        Console.Write(n);
    }
}


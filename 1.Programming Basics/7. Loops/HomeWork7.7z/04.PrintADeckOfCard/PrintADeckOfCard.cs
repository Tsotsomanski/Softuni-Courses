﻿using System;
using System.Text;

class PrintADeckOfCard
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.GetEncoding(1252);

        Console.WriteLine("Write a program that generates and prints all possible cards from a standard deck of 52 cards (without the jokers). The cards should be printed using the classical notation (like 5♠, A♥, 9♣ and K♦). The card faces should start from 2 to A. Print each card face in its four possible suits: clubs, diamonds, hearts and spades. Use 2 nested for-loops and a switch-case statement.");
        Console.WriteLine();
        
        string[] paints = new string[] { "Clubs", "Diamonds", "Hearts", "Spades" };
        string[] playingCards = new string[] { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };

        for (int p = 0; p < playingCards.Length; p++)
        {
            for (int c = 0; c < paints.Length; c++)
            {
                switch (paints[c])
                {
                    case "Clubs":
                        Console.Write(playingCards[p] + (char)005);
                        break;
                    case "Diamonds":
                        Console.Write(playingCards[p] + (char)004);
                        break;
                    case "Hearts":
                        Console.Write(playingCards[p] + (char)003);
                        break;
                    case "Spades":
                        Console.Write(playingCards[p] + (char)006);
                        break;
                    default:
                        Console.Write("Invalid paint");
                        break;
                }
                Console.Write(" ");
            }
            Console.WriteLine();
        }
    }
}


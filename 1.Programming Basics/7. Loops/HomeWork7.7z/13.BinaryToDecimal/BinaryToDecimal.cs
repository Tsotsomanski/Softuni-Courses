﻿using System;
class BinaryToDecimal
{
    static void Main()
    {
        Console.WriteLine("Using loops write a program that converts a binary integer number to its decimal form. The input is entered as string. The output should be a variable of type long. Do not use the built-in .NET functionality. ");
        Console.WriteLine();
        Console.WriteLine("Variant 1");
        Console.WriteLine("Enter a binary number: ");
        string binNumber = Console.ReadLine();
        long decNumber = 0;
        int power = 1;
        for (int i = binNumber.Length - 1; i >= 0; i--)
        {
            int num = binNumber[i] - 48;
            decNumber += num * power;
            power *= 2;
        }
        Console.WriteLine(decNumber);
        Console.WriteLine();

        Console.WriteLine("Variant 2");
        Console.WriteLine("Enter a binary number: ");
        string binaryNum = Console.ReadLine();
        
        for (int i = 0; i >= 0; i--)
        {
            int decimalNum = Convert.ToInt32(binaryNum, 2);
            Console.WriteLine("The decimal representation is: {0}", decimalNum);
        }
    }
}
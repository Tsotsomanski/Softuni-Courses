﻿namespace Estates.Interfaces
{
    public enum EstateType
    {
        Apartment,
        Office,
        House,
        Garage
    }
}
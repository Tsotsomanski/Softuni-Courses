﻿namespace Estates.Interfaces
{
    public enum OfferType
    {
        Sale,
        Rent
    }
}

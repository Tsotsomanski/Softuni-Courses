﻿using System;
using System.Threading;
using Estates.Data;
using Estates.Interfaces;

namespace Estates
{
    class ProgramTest
    {
        //Apartment apartment = new Apartment("Luxe", EstateType.Apartment, 130, "Sofia", true);
        //Offise offiseOne = new Offise("Bussines office", EstateType.Office, 80, "Varna", true, 1, true);
        //House house = new House("Sea house", EstateType.House, 250, "Sunny Beach", false, 2);
        //Garage garage= new Garage("MotoGarage", EstateType.Garage, 20, "Sofia", false, 5, 4);
        //RentOffer greenOffis new RentOffer(OfferType.Rent, EstateType.Office, 500);
        //Offer blueOffis = new RentOffer();
        //SaleOffer bigHouse = new SaleOffer(OfferType.Sale, EstateType.House, 2000);
    }
}

﻿using System;
class NumberAsWord2
{
    static void Main()
    {
        Console.WriteLine("Enter an integer number [0..999] and press enter!");
        uint userInput = uint.Parse(Console.ReadLine());

        uint hundreds = userInput / 100;
        uint tenth = (userInput / 10) % 10;
        uint unit = userInput % 10;
        string str = null;

        string[] units = { null, "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eightteen", "nineteen" };
        string[] unitsCaps = { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen", "Nineteen" };
        string[] tenths = { null, "ten", "twenty", "thirty", "fourty", "fifty", "sixty", "seventy", "eighty", "ninety" };
        string[] tenthsCaps = { null, "Ten", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

        if ((userInput >= 0) && (userInput <= 19))
        {
            str = unitsCaps[userInput];
        }

        if ((userInput >= 20) && (userInput <= 99))
        {
            str = tenthsCaps[tenth] + " " + units[unit];
        }

        if ((userInput >= 100) && (tenth == 0) && (unit == 0))
        {
            str = unitsCaps[hundreds] + " hundred ";
        }

        if ((userInput >= 100) && (tenth == 0) && (unit != 0))
        {
            str = unitsCaps[hundreds] + " hundreds and " + units[unit];
        }

        if ((userInput >= 100) && (tenth != 0))
	    {
		    str = unitsCaps[hundreds] + " hundred and " + tenths[tenth] + " " + units[unit];
	    }

        Console.WriteLine(str);

    }
}


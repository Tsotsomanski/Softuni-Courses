﻿using System;
class BonusScore
{
    static void Main()
    {
        int multiplie = int.Parse(Console.ReadLine());

        if (multiplie >= 1 && multiplie <= 3)
        {
            Console.WriteLine(multiplie * 10);
        }
        else if (multiplie >= 4 && multiplie <= 6)
        {
            Console.WriteLine(multiplie * 100);
        }
        else if (multiplie >= 7 && multiplie <= 9)
        {
            Console.WriteLine(multiplie * 1000);
        }
        else
        {
            Console.WriteLine("The score is invalid !");
        }
    }
}


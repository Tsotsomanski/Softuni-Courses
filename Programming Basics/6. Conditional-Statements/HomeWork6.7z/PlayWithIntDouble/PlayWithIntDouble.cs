﻿using System;
class PlayWithIntDouble
{
    static void Main()
    {
        Console.WriteLine("Please choose a type: \n1 --> Int; \n2 --> Double; \n3 --> String");
        Console.WriteLine();
        int choise = int.Parse(Console.ReadLine());
        Console.WriteLine();

        switch (choise)
        {
            case 1: Console.WriteLine("Enter a integer: ");
                    int a = int.Parse(Console.ReadLine());
                    Console.WriteLine();
                    Console.WriteLine(a + 1);
                    break;

            case 2: Console.WriteLine("Enter a double: ");
                    double b = double.Parse(Console.ReadLine());
                    Console.WriteLine();
                    Console.WriteLine(b + 1);
                    break;

            case 3: Console.WriteLine("Enter a string: ");
                    string c = Console.ReadLine();
                    Console.WriteLine();
                    Console.WriteLine(c + " * ");
                    break;
        }
    }
}


﻿using System;
class ExchangeGreater
{
    static void Main()
    {
        Console.WriteLine("Enter first number: ");
        double a = double.Parse(Console.ReadLine());
        Console.WriteLine("Enter second number: ");
        double b = double.Parse(Console.ReadLine());

        if (a > b)
        {
            Console.WriteLine("First is greater so here is the exchange: ");
            Console.WriteLine("first = " + Math.Abs((a + b) - a));
            Console.WriteLine("second = " + Math.Abs((b + a) - b));
        }
        else 
        {
            Console.WriteLine("Second is greater so we don't do exchange: ");
            Console.WriteLine("first = {0}", a);
            Console.WriteLine("second = {0}", b);
        }
    }
}


﻿using System;
class Program
{
    static void Main()
    {
        for (int i = 2, j = -3; i < 12; i+=2,j-=2)
        {
            Console.Write(i + ",");
            Console.Write(j + ",");
        }
    }
}

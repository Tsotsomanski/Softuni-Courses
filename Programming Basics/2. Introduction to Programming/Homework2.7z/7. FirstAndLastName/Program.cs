﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstAndLastName
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Aleksandar");
            Console.WriteLine("Tsotsomanski");
        }
    }
}

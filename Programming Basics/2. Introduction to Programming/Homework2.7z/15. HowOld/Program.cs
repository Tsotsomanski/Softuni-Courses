﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Enter your age: ");
        int age = int.Parse(Console.ReadLine());
        Console.Write("You are " + age + " years old. ");
        Console.WriteLine(" After 10 years you will be " + (age + 10));
    }
}


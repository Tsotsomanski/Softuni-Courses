﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroToCSharp
{
    class HelloCSharp       
    {
        static void Main()
        {
            System.Console.WriteLine("Hello C#!");
        }
    }
}

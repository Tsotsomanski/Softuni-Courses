﻿namespace Exam_20_12._15.Enums
{
    public enum BlobType
    {
        AggresiveeBlub,
        InflatedBlub
    }
}

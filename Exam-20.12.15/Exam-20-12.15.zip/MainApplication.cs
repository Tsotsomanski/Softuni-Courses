﻿namespace Exam_20_12._15
{
    class MainApplication
    {
        static void Main()
        {

        }
    }
}

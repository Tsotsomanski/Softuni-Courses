﻿namespace Exam_20_12._15.Interfaces
{
    public interface IDestroyable
    {
        int BlobHealth { get; }
    }
}

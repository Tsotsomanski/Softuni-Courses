﻿namespace Exam_20_12._15.Interfaces
{
    interface IInputReader
    {
        string ReadLine();
    }
}

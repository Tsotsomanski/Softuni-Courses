﻿namespace Exam_20_12._15.Interfaces
{
    interface IOutputWriter
    {
        void Print(string message);
    }
}

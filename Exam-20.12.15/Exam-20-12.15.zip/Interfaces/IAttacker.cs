﻿namespace Exam_20_12._15.Interfaces
{
    public interface IAttacker
    {
        int BlobAttackDamage { get; }
    }
}

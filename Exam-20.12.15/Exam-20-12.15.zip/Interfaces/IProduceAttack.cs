﻿namespace Exam_20_12._15.Models.Attack
{
    public interface IProduceAttack
    {
        int ProduceAttack();
    }
}

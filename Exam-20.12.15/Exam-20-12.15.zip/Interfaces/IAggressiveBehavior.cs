﻿namespace Exam_20_12._15.Interfaces
{
    public interface IAggressiveBehavior : IBehavior
    {
        int DoublesBlobDamage();
        int BlobLosesDamage();
    }
}

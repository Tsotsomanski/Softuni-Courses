﻿namespace Exam_20_12._15.Interfaces
{
    public interface IInflatedBehavior : IBehavior
    {
        int BlobGainsHealth();
        int BlobLosesHealth();
    }
}
